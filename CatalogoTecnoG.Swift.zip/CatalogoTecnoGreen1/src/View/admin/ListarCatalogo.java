package View.admin;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import Font.Catalogo;
import Font.SerVivo;
import java.io.File;

public class ListarCatalogo extends JPanel {
    private JTable tabela;
    private DefaultTableModel modeloTabela;
    private JLabel lblDetalhes;
    private JLabel lblFoto;

    public ListarCatalogo(Catalogo catalogo) {
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);

        // Título
        JLabel lblTitulo = new JLabel("Catálogo de Animais");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 26));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setForeground(new Color(0x007BFF));

        // Tabela resumida
        modeloTabela = new DefaultTableModel(
            new Object[]{"Nome Popular", "Classificação"}, 0
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabela = new JTable(modeloTabela);
        tabela.setRowHeight(28);
        tabela.setFont(new Font("Arial", Font.PLAIN, 15));
        tabela.getTableHeader().setFont(new Font("Arial", Font.BOLD, 15));
        JScrollPane scrollTabela = new JScrollPane(tabela);

        // Painel de detalhes
        JPanel painelDetalhes = new JPanel(new BorderLayout(10, 10));
        lblDetalhes = new JLabel("Selecione um animal para ver detalhes.");
        lblDetalhes.setFont(new Font("Arial", Font.ITALIC, 14));
        lblDetalhes.setVerticalAlignment(SwingConstants.TOP);
        lblFoto = new JLabel("Sem foto");
        lblFoto.setHorizontalAlignment(JLabel.CENTER);
        lblFoto.setPreferredSize(new Dimension(220, 220));
        lblFoto.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
        lblFoto.setOpaque(true);
        lblFoto.setBackground(Color.LIGHT_GRAY);

        painelDetalhes.add(lblDetalhes, BorderLayout.CENTER);
        painelDetalhes.add(lblFoto, BorderLayout.EAST);

        // Layout
        add(lblTitulo, BorderLayout.NORTH);
        add(scrollTabela, BorderLayout.CENTER);
        add(painelDetalhes, BorderLayout.SOUTH);

        // Preencher tabela resumida
        atualizarTabela(catalogo);

        // Ao clicar em uma linha, mostra detalhes e foto
        tabela.getSelectionModel().addListSelectionListener(e -> {
            int linha = tabela.getSelectedRow();
            if (linha >= 0) {
                String nomePopular = (String) modeloTabela.getValueAt(linha, 0);
                SerVivo ser = catalogo.buscarPorNomePopular(nomePopular);
                if (ser != null) {
                    lblDetalhes.setText(
                        "<html><b>Nome Popular:</b> " + ser.getNomePopular() +
                        "<br><b>Nome Científico:</b> " + ser.getNomeCientifico() +
                        "<br><b>Classificação:</b> " + ser.getClassificacao() +
                        "<br><b>Descrição:</b> " + ser.getDescricao() + "</html>"
                    );
                    mostrarFoto(ser.getNomePopular());
                }
            }
        });
    }

    // Atualiza a tabela com os dados do catálogo
    public void atualizarTabela(Catalogo catalogo) {
        List<SerVivo> lista = catalogo.getTodosSeresVivos();
        modeloTabela.setRowCount(0);
        for (SerVivo ser : lista) {
            modeloTabela.addRow(new Object[]{
                ser.getNomePopular(),
                ser.getClassificacao()
            });
        }
        lblDetalhes.setText("Selecione um animal para ver detalhes.");
        lblFoto.setIcon(null);
        lblFoto.setText("Sem foto");
    }

    // Mostra a foto do animal, se existir
    private void mostrarFoto(String nomeAnimal) {
        File pastaFotos = new File("fotos");
        File fotoJpg = new File(pastaFotos, nomeAnimal + ".jpg");
        File fotoPng = new File(pastaFotos, nomeAnimal + ".png");
        File foto = fotoJpg.exists() ? fotoJpg : (fotoPng.exists() ? fotoPng : null);

        if (foto != null && foto.exists()) {
            ImageIcon icon = new ImageIcon(foto.getAbsolutePath());
            Image img = icon.getImage().getScaledInstance(220, 220, Image.SCALE_SMOOTH);
            lblFoto.setIcon(new ImageIcon(img));
            lblFoto.setText("");
        } else {
            lblFoto.setIcon(null);
            lblFoto.setText("Sem foto");
        }
    }
}
