package View.admin;

import javax.swing.*;
import java.awt.*;
import Font.Catalogo;

public class DashboardAdmin extends JFrame {
    private JPanel painelMenu;
    private JPanel painelConteudo;

    public DashboardAdmin(Catalogo catalogo) {
        setTitle("Painel Administrativo - Catálogo de Animais");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Menu lateral
        painelMenu = new JPanel();
        painelMenu.setLayout(new GridLayout(6, 1, 0, 10));
        painelMenu.setBackground(new Color(0x007BFF));

        JButton btnListar = new JButton("Listar Animais");
        JButton btnCadastrar = new JButton("Cadastrar Animal");
        JButton btnEditar = new JButton("Editar Animal");
        JButton btnFotos = new JButton("Gerenciar Fotos");
        JButton btnVoltar = new JButton("Voltar");

        painelMenu.add(btnListar);
        painelMenu.add(btnCadastrar);
        painelMenu.add(btnEditar);
        painelMenu.add(btnFotos);
        painelMenu.add(btnVoltar);

        // Painel de conteúdo
        painelConteudo = new JPanel(new CardLayout());
        painelConteudo.add(new ListarCatalogo(catalogo), "listar");
        painelConteudo.add(new CadastrarAnimal(catalogo), "cadastrar");
        painelConteudo.add(new EditarAnimal(catalogo), "editar");
        painelConteudo.add(new Fotos(catalogo), "fotos");

        add(painelMenu, BorderLayout.WEST);
        add(painelConteudo, BorderLayout.CENTER);

        // Troca o painel conforme o botão
        btnListar.addActionListener(e -> mostrarPainel("listar"));
        btnCadastrar.addActionListener(e -> mostrarPainel("cadastrar"));
        btnEditar.addActionListener(e -> mostrarPainel("editar"));
        btnFotos.addActionListener(e -> mostrarPainel("fotos"));
        btnVoltar.addActionListener(e -> {
            dispose();      // Fecha o painel admin
            new View.Mainswing(); // Volta para a tela inicial
        });

        setVisible(true);
        mostrarPainel("listar");
    }

    private void mostrarPainel(String nome) {
        CardLayout cl = (CardLayout) (painelConteudo.getLayout());
        cl.show(painelConteudo, nome);
    }
}
