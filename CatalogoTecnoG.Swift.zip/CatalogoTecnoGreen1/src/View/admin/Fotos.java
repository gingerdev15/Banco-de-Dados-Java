package View.admin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.Normalizer;
import java.util.*;
import Font.Catalogo;
import Font.SerVivo;

public class Fotos extends JPanel {
    private JComboBox<String> comboCategoria;
    private JComboBox<String> comboAnimais;
    private JPanel painelGaleria;
    private Catalogo catalogo;

    // Define o diretório base para as fotos como um caminho absoluto
    // Garante que a pasta "fotos" esteja no mesmo diretório do JAR/execução
    private static final String FOTOS_BASE_DIR = System.getProperty("user.dir") + File.separator + "fotos";


    public Fotos(Catalogo catalogo) {
        this.catalogo = catalogo;
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);

        // Certifica que o diretório base de fotos existe
        File baseDir = new File(FOTOS_BASE_DIR);
        if (!baseDir.exists()) {
            baseDir.mkdirs();
        }
        System.out.println("Diretório base das fotos: " + FOTOS_BASE_DIR); // Para depuração

        // Topo: seleção da categoria, animal e botões
        JPanel painelTopo = new JPanel();
        painelTopo.setBackground(Color.WHITE);

        comboCategoria = new JComboBox<>();
        comboAnimais = new JComboBox<>();

        // Preenche categorias únicas
        Set<String> categorias = new TreeSet<>();
        for (SerVivo ser : catalogo.getLista()) {
            categorias.add(ser.getClassificacao());
        }
        comboCategoria.addItem("Selecione a categoria");
        for (String cat : categorias) {
            comboCategoria.addItem(cat);
        }

        JButton btnAdicionar = new JButton("Adicionar Foto");

        painelTopo.add(new JLabel("Categoria:"));
        painelTopo.add(comboCategoria);
        painelTopo.add(new JLabel("Animal:"));
        painelTopo.add(comboAnimais);
        painelTopo.add(btnAdicionar);

        add(painelTopo, BorderLayout.NORTH);

        // Galeria de fotos
        painelGaleria = new JPanel();
        painelGaleria.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        painelGaleria.setBackground(Color.WHITE);

        JScrollPane scrollGaleria = new JScrollPane(painelGaleria);
        scrollGaleria.setPreferredSize(new Dimension(600, 350));
        add(scrollGaleria, BorderLayout.CENTER);

        // Eventos
        comboCategoria.addActionListener(e -> atualizarComboAnimais());
        comboAnimais.addActionListener(e -> atualizarGaleria());
        btnAdicionar.addActionListener(e -> adicionarFoto());

        // Inicializa combos
        if (comboCategoria.getItemCount() > 1) {
            comboCategoria.setSelectedIndex(1); // Seleciona a primeira categoria real
        }
    }

    private void atualizarComboAnimais() {
        comboAnimais.removeAllItems();
        String categoria = (String) comboCategoria.getSelectedItem();
        if (categoria == null || categoria.equals("Selecione a categoria")) return;

        for (SerVivo ser : catalogo.getLista()) {
            if (ser.getClassificacao().equals(categoria)) {
                comboAnimais.addItem(ser.getNomePopular());
            }
        }
        if (comboAnimais.getItemCount() > 0) {
            comboAnimais.setSelectedIndex(0);
            atualizarGaleria();
        } else {
            painelGaleria.removeAll();
            painelGaleria.add(new JLabel("Nenhum animal nesta categoria."));
            painelGaleria.revalidate();
            painelGaleria.repaint();
        }
    }

    private void atualizarGaleria() {
        painelGaleria.removeAll();
        String nomeAnimal = (String) comboAnimais.getSelectedItem();
        if (nomeAnimal == null) {
            painelGaleria.add(new JLabel("Selecione um animal."));
            painelGaleria.revalidate();
            painelGaleria.repaint();
            return;
        }

        // Usa o caminho absoluto para a pasta do animal
        File pastaAnimal = new File(FOTOS_BASE_DIR, normalizarNome(nomeAnimal));
        System.out.println("Tentando carregar fotos de: " + pastaAnimal.getAbsolutePath()); // Para depuração

        if (!pastaAnimal.exists()) pastaAnimal.mkdirs();

        File[] fotos = pastaAnimal.listFiles((dir, name) -> {
            String lower = name.toLowerCase();
            return lower.endsWith(".jpg") || lower.endsWith(".png") || lower.endsWith(".jpeg");
        });

        if (fotos != null && fotos.length > 0) {
            for (File foto : fotos) {
                System.out.println("Processando foto: " + foto.getAbsolutePath() + ", Existe: " + foto.exists()); // Para depuração
                ImageIcon icon = new ImageIcon(foto.getAbsolutePath());

                // Adicionado verificação de status de carregamento da imagem
                if (icon.getImageLoadStatus() == MediaTracker.COMPLETE) {
                    Image img = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    JLabel lblFoto = new JLabel(new ImageIcon(img));
                    lblFoto.setPreferredSize(new Dimension(100, 100));
                    lblFoto.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
                    lblFoto.setToolTipText(foto.getName());

                    // Clique para ver maior
                    lblFoto.addMouseListener(new MouseAdapter() {
                        public void mouseClicked(MouseEvent e) {
                            mostrarFotoGrande(foto);
                        }
                    });

                    // Botão para remover
                    JButton btnRemover = new JButton("X");
                    btnRemover.setMargin(new Insets(2, 2, 2, 2));
                    btnRemover.setForeground(Color.RED);
                    btnRemover.addActionListener(ev -> {
                        foto.delete();
                        atualizarGaleria();
                    });

                    JPanel painelFoto = new JPanel(new BorderLayout());
                    painelFoto.setOpaque(false);
                    painelFoto.add(lblFoto, BorderLayout.CENTER);
                    painelFoto.add(btnRemover, BorderLayout.NORTH);

                    painelGaleria.add(painelFoto);
                } else {
                    System.err.println("Erro ao carregar imagem: " + foto.getAbsolutePath());
                    JLabel lblErro = new JLabel("Erro ao carregar imagem: " + foto.getName());
                    lblErro.setPreferredSize(new Dimension(100, 100));
                    painelGaleria.add(lblErro);
                }
            }
        } else {
            painelGaleria.add(new JLabel("Nenhuma foto para este animal."));
        }
        painelGaleria.revalidate();
        painelGaleria.repaint();
    }

    private void adicionarFoto() {
        String nomeAnimal = (String) comboAnimais.getSelectedItem();
        if (nomeAnimal == null) return;

        // Usa o caminho absoluto para a pasta do animal
        File pastaAnimal = new File(FOTOS_BASE_DIR, normalizarNome(nomeAnimal));
        System.out.println("Salvando foto em: " + pastaAnimal.getAbsolutePath()); // Para depuração

        if (!pastaAnimal.exists()) pastaAnimal.mkdirs();

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Escolha uma foto (jpg, png)");
        int resultado = chooser.showOpenDialog(this);
        if (resultado == JFileChooser.APPROVE_OPTION) {
            File origem = chooser.getSelectedFile();
            String extensao = getExtensao(origem.getName());
            String nomeFoto = "foto_" + System.currentTimeMillis() + extensao;
            File destino = new File(pastaAnimal, nomeFoto);

            try {
                Files.copy(origem.toPath(), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
                atualizarGaleria();
                JOptionPane.showMessageDialog(this, "Foto adicionada com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao salvar foto: " + ex.getMessage());
                ex.printStackTrace(); // Imprime a pilha de chamadas para depuração
            }
        }
    }

    private void mostrarFotoGrande(File foto) {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Visualizar Foto", true);
        dialog.setSize(500, 500);
        dialog.setLocationRelativeTo(this);
        ImageIcon icon = new ImageIcon(foto.getAbsolutePath());
        Image img = icon.getImage().getScaledInstance(480, 480, Image.SCALE_SMOOTH);
        JLabel lbl = new JLabel(new ImageIcon(img));
        dialog.add(lbl);
        dialog.setVisible(true);
    }

    private String getExtensao(String nomeArquivo) {
        int i = nomeArquivo.lastIndexOf('.');
        if (i > 0) {
            return nomeArquivo.substring(i);
        }
        return ".jpg"; // Default se não encontrar extensão
    }

    // Remove acentos, espaços e caracteres especiais do nome da pasta
    private String normalizarNome(String nome) {
        String n = Normalizer.normalize(nome, Normalizer.Form.NFD)
                .replaceAll("[^\\p{ASCII}]", "")
                .replaceAll("[^a-zA-Z0-9_-]", "_");
        return n;
    }
}