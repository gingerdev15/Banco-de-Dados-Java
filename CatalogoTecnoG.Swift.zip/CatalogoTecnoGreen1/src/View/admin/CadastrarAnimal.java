package View.admin;

import javax.swing.*;
import java.awt.*;
import Font.Animal;
import Font.Catalogo;
import java.io.IOException;

public class CadastrarAnimal extends JPanel {
    private JTextField txtNomePopular;
    private JTextField txtNomeCientifico;
    private JTextField txtClassificacao;
    private JTextArea txtDescricao;
    private JLabel lblStatus;

    public CadastrarAnimal(Catalogo catalogo) {
        setLayout(new GridBagLayout());
        setOpaque(false);

        JLabel lblTitulo = new JLabel("Cadastrar Animal");
        lblTitulo.setFont(new Font("Montserrat", Font.BOLD, 22));
        lblTitulo.setForeground(new Color(0x333333));

        JLabel lblNomePopular = new JLabel("Nome Popular:");
        JLabel lblNomeCientifico = new JLabel("Nome Científico:");
        JLabel lblClassificacao = new JLabel("Classificação:");
        JLabel lblDescricao = new JLabel("Descrição:");

        txtNomePopular = new JTextField(20);
        txtNomeCientifico = new JTextField(20);
        txtClassificacao = new JTextField(20);
        txtDescricao = new JTextArea(5, 20);
        JScrollPane scrollDesc = new JScrollPane(txtDescricao);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnLimpar = new JButton("Limpar");

        lblStatus = new JLabel(" ");
        lblStatus.setForeground(new Color(0x007BFF));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(lblTitulo, gbc);

        gbc.gridwidth = 1; gbc.gridy++;
        gbc.gridx = 0;
        add(lblNomePopular, gbc);
        gbc.gridx = 1;
        add(txtNomePopular, gbc);

        gbc.gridx = 0; gbc.gridy++;
        add(lblNomeCientifico, gbc);
        gbc.gridx = 1;
        add(txtNomeCientifico, gbc);

        gbc.gridx = 0; gbc.gridy++;
        add(lblClassificacao, gbc);
        gbc.gridx = 1;
        add(txtClassificacao, gbc);

        gbc.gridx = 0; gbc.gridy++;
        add(lblDescricao, gbc);
        gbc.gridx = 1;
        add(scrollDesc, gbc);

        gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2;
        JPanel botoes = new JPanel();
        botoes.setOpaque(false);
        botoes.add(btnSalvar);
        botoes.add(btnLimpar);
        add(botoes, gbc);

        gbc.gridy++;
        add(lblStatus, gbc);

        // Ação do botão Salvar
        btnSalvar.addActionListener(e -> {
            String nomePopular = txtNomePopular.getText().trim();
            String nomeCientifico = txtNomeCientifico.getText().trim();
            String classificacao = txtClassificacao.getText().trim();
            String descricao = txtDescricao.getText().trim();

            if (nomePopular.isEmpty() || nomeCientifico.isEmpty() || classificacao.isEmpty() || descricao.isEmpty()) {
                lblStatus.setText("Preencha todos os campos");
                lblStatus.setForeground(Color.RED);
            } else {
                Animal animal = new Animal(nomePopular, nomeCientifico, classificacao, descricao);
                try {
                    catalogo.adicionarSerVivo(animal);
                    lblStatus.setText("Animal cadastrado com sucesso!");
                    lblStatus.setForeground(new Color(0x007BFF));
                    // Limpar campos após cadastro
                    txtNomePopular.setText("");
                    txtNomeCientifico.setText("");
                    txtClassificacao.setText("");
                    txtDescricao.setText("");
                } catch (IllegalArgumentException ex) {
                    lblStatus.setText(ex.getMessage());
                    lblStatus.setForeground(Color.RED);
                } catch (IOException ex) {
                    lblStatus.setText("Erro ao salvar: " + ex.getMessage());
                    lblStatus.setForeground(Color.RED);
                    ex.printStackTrace();
                }
            }
        });

        // Ação do botão Limpar
        btnLimpar.addActionListener(e -> {
            txtNomePopular.setText("");
            txtNomeCientifico.setText("");
            txtClassificacao.setText("");
            txtDescricao.setText("");
            lblStatus.setText(" ");
            lblStatus.setForeground(new Color(0x007BFF));
        });
    }
}
