package View.admin;

import javax.swing.*;
import java.awt.*;
import Font.Catalogo;
import Font.SerVivo;
import java.io.IOException;

public class EditarAnimal extends JPanel {
    private JTextField txtBuscaPopular;
    private JTextField txtBuscaCientifico;
    private JTextField txtNomePopular;
    private JTextField txtNomeCientifico;
    private JTextField txtClassificacao;
    private JTextArea txtDescricao;
    private JLabel lblStatus;
    private JComboBox<String> comboClassificacoes;
    private JComboBox<String> comboAnimais;
    private SerVivo animalEditando = null;

    public EditarAnimal(Catalogo catalogo) {
        setLayout(new GridBagLayout());

        JLabel lblTitulo = new JLabel("Editar Animal");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));

        // Busca por nome popular
        JLabel lblBuscaPopular = new JLabel("Nome Popular:");
        txtBuscaPopular = new JTextField(15);
        JButton btnBuscarPopular = new JButton("Buscar");

        // Busca por nome científico
        JLabel lblBuscaCientifico = new JLabel("Nome Científico:");
        txtBuscaCientifico = new JTextField(15);
        JButton btnBuscarCientifico = new JButton("Buscar");

        // Busca por classificação
        comboClassificacoes = new JComboBox<>();
        for (String classif : catalogo.getClassificacoesDisponiveis()) {
            comboClassificacoes.addItem(classif);
        }
        comboAnimais = new JComboBox<>();

        // Campos de edição
        JLabel lblNomePopular = new JLabel("Nome Popular:");
        JLabel lblNomeCientifico = new JLabel("Nome Científico:");
        JLabel lblClassificacao = new JLabel("Classificação:");
        JLabel lblDescricao = new JLabel("Descrição:");

        txtNomePopular = new JTextField(20);
        txtNomeCientifico = new JTextField(20);
        txtClassificacao = new JTextField(20);
        txtDescricao = new JTextArea(4, 20);
        JScrollPane scrollDesc = new JScrollPane(txtDescricao);

        JButton btnSalvar = new JButton("Salvar Alterações");
        JButton btnLimpar = new JButton("Limpar");
        lblStatus = new JLabel(" ");

        // Layout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(lblTitulo, gbc);

        // Busca por nome popular
        gbc.gridwidth = 1; gbc.gridy++;
        add(lblBuscaPopular, gbc);
        gbc.gridx = 1;
        add(txtBuscaPopular, gbc);
        gbc.gridx = 2;
        add(btnBuscarPopular, gbc);

        // Busca por nome científico
        gbc.gridx = 0; gbc.gridy++;
        add(lblBuscaCientifico, gbc);
        gbc.gridx = 1;
        add(txtBuscaCientifico, gbc);
        gbc.gridx = 2;
        add(btnBuscarCientifico, gbc);

        // Busca por classificação
        gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("Classificação:"), gbc);
        gbc.gridx = 1;
        add(comboClassificacoes, gbc);

        gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("Animais encontrados:"), gbc);
        gbc.gridx = 1;
        add(comboAnimais, gbc);

        // Campos de edição
        gbc.gridx = 0; gbc.gridy++;
        add(lblNomePopular, gbc);
        gbc.gridx = 1;
        add(txtNomePopular, gbc);

        gbc.gridx = 0; gbc.gridy++;
        add(lblNomeCientifico, gbc);
        gbc.gridx = 1;
        add(txtNomeCientifico, gbc);

        gbc.gridx = 0; gbc.gridy++;
        add(lblClassificacao, gbc);
        gbc.gridx = 1;
        add(txtClassificacao, gbc);

        gbc.gridx = 0; gbc.gridy++;
        add(lblDescricao, gbc);
        gbc.gridx = 1;
        add(scrollDesc, gbc);

        // Botões
        gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 3;
        JPanel botoes = new JPanel();
        botoes.add(btnSalvar);
        botoes.add(btnLimpar);
        add(botoes, gbc);

        gbc.gridy++;
        add(lblStatus, gbc);

        // Ação do botão Buscar por nome popular
        btnBuscarPopular.addActionListener(e -> {
            String busca = txtBuscaPopular.getText().trim();
            animalEditando = catalogo.buscarPorNomePopular(busca);
            preencherCampos(animalEditando);
        });

        // Ação do botão Buscar por nome científico
        btnBuscarCientifico.addActionListener(e -> {
            String busca = txtBuscaCientifico.getText().trim();
            animalEditando = catalogo.buscarPorNomeCientifico(busca);
            preencherCampos(animalEditando);
        });

        // Quando selecionar uma classificação, preenche os animais
        comboClassificacoes.addActionListener(e -> {
            comboAnimais.removeAllItems();
            String classif = (String) comboClassificacoes.getSelectedItem();
            if (classif != null) {
                for (SerVivo ser : catalogo.buscarPorClassificacao(classif)) {
                    comboAnimais.addItem(ser.getNomePopular());
                }
            }
        });

        // Quando selecionar um animal, preenche os campos
        comboAnimais.addActionListener(e -> {
            String nome = (String) comboAnimais.getSelectedItem();
            if (nome != null) {
                animalEditando = catalogo.buscarPorNomePopular(nome);
                preencherCampos(animalEditando);
            }
        });

        // Salvar alterações
        btnSalvar.addActionListener(e -> {
            if (animalEditando == null) {
                lblStatus.setText("Busque ou selecione um animal primeiro.");
                lblStatus.setForeground(Color.RED);
                return;
            }
            String nomePopular = txtNomePopular.getText().trim();
            String nomeCientifico = txtNomeCientifico.getText().trim();
            String classificacao = txtClassificacao.getText().trim();
            String descricao = txtDescricao.getText().trim();

            if (nomePopular.isEmpty() || nomeCientifico.isEmpty() || classificacao.isEmpty() || descricao.isEmpty()) {
                lblStatus.setText("Preencha todos os campos.");
                lblStatus.setForeground(Color.RED);
            } else {
                animalEditando.setNomePopular(nomePopular);
                animalEditando.setNomeCientifico(nomeCientifico);
                animalEditando.setClassificacao(classificacao);
                animalEditando.setDescricao(descricao);
                try {
                    catalogo.atualizarSerVivo(animalEditando);
                    lblStatus.setText("Animal atualizado com sucesso!");
                    lblStatus.setForeground(new Color(0x007BFF));
                } catch (IOException | IllegalArgumentException ex) {
                    lblStatus.setText("Erro ao salvar: " + ex.getMessage());
                    lblStatus.setForeground(Color.RED);
                    ex.printStackTrace();
                }
            }
        });

        // Limpar tudo
        btnLimpar.addActionListener(e -> {
            txtBuscaPopular.setText("");
            txtBuscaCientifico.setText("");
            txtNomePopular.setText("");
            txtNomeCientifico.setText("");
            txtClassificacao.setText("");
            txtDescricao.setText("");
            lblStatus.setText(" ");
            animalEditando = null;
        });
    }

    // Método para preencher os campos
    private void preencherCampos(SerVivo ser) {
        if (ser != null) {
            txtNomePopular.setText(ser.getNomePopular());
            txtNomeCientifico.setText(ser.getNomeCientifico());
            txtClassificacao.setText(ser.getClassificacao());
            txtDescricao.setText(ser.getDescricao());
            lblStatus.setText("Animal encontrado. Edite e salve.");
            lblStatus.setForeground(new Color(0x007BFF));
        } else {
            lblStatus.setText("Animal não encontrado.");
            lblStatus.setForeground(Color.RED);
            txtNomePopular.setText("");
            txtNomeCientifico.setText("");
            txtClassificacao.setText("");
            txtDescricao.setText("");
        }
    }
}