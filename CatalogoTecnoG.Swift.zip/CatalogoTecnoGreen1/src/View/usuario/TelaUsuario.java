package View.usuario;

import javax.swing.*;
import java.awt.*;
import Font.Catalogo;
import Font.SerVivo;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.table.DefaultTableModel;

public class TelaUsuario extends JFrame {
    public TelaUsuario(Catalogo catalogo) {
        setTitle("Catálogo de Animais - Usuário");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);

        // Menu lateral
        JPanel painelMenu = new JPanel();
        painelMenu.setLayout(new GridLayout(4, 1, 0, 10));
        painelMenu.setBackground(new Color(0x009688));

        JButton btnCatalogo = new JButton("Ver Catálogo");
        JButton btnSobre = new JButton("Sobre");
        JButton btnVoltar = new JButton("Voltar");

        painelMenu.add(btnCatalogo);
        painelMenu.add(btnSobre);
        painelMenu.add(btnVoltar);

        // Painel de conteúdo
        JPanel painelConteudo = new JPanel(new CardLayout());

        // Painel de busca e catálogo
        JPanel painelBusca = new JPanel(new BorderLayout(10, 10));
        painelBusca.setBackground(Color.WHITE);

        // Filtros de busca
        JPanel painelFiltros = new JPanel();
        painelFiltros.setBackground(Color.WHITE);
        JTextField txtBusca = new JTextField(18);
        JComboBox<String> comboClassificacao = new JComboBox<>();
        comboClassificacao.addItem("Todas");
        for (String classif : catalogo.getClassificacoesDisponiveis()) {
            comboClassificacao.addItem(classif);
        }
        JButton btnFiltrar = new JButton("Buscar");

        painelFiltros.add(new JLabel("Nome:"));
        painelFiltros.add(txtBusca);
        painelFiltros.add(new JLabel("Classificação:"));
        painelFiltros.add(comboClassificacao);
        painelFiltros.add(btnFiltrar);

        // Tabela de animais
        String[] colunas = {"Nome Popular", "Classificação"};
        DefaultTableModel modeloTabela = new DefaultTableModel(colunas, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        JTable tabela = new JTable(modeloTabela);
        tabela.setRowHeight(28);
        tabela.setFont(new Font("Arial", Font.PLAIN, 15));
        tabela.getTableHeader().setFont(new Font("Arial", Font.BOLD, 15));
        JScrollPane scrollTabela = new JScrollPane(tabela);

        // Detalhes e foto
        JPanel painelDetalhes = new JPanel(new BorderLayout(10, 10));
        JLabel lblDetalhes = new JLabel("Selecione um animal para ver detalhes.");
        lblDetalhes.setFont(new Font("Arial", Font.ITALIC, 14));
        lblDetalhes.setVerticalAlignment(SwingConstants.TOP);
        JLabel lblFoto = new JLabel("Sem foto");
        lblFoto.setHorizontalAlignment(JLabel.CENTER);
        lblFoto.setPreferredSize(new Dimension(220, 220));
        lblFoto.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
        lblFoto.setOpaque(true);
        lblFoto.setBackground(Color.LIGHT_GRAY);

        painelDetalhes.add(lblDetalhes, BorderLayout.CENTER);
        painelDetalhes.add(lblFoto, BorderLayout.EAST);

        painelBusca.add(painelFiltros, BorderLayout.NORTH);
        painelBusca.add(scrollTabela, BorderLayout.CENTER);
        painelBusca.add(painelDetalhes, BorderLayout.SOUTH);

        painelConteudo.add(painelBusca, "catalogo");

        // Painel Sobre
        JPanel painelSobre = new JPanel();
        painelSobre.setBackground(Color.WHITE);
        painelSobre.add(new JLabel(
            "<html>" +
            "<h2>Catálogo de Animais</h2>" +
            "<p>Projeto acadêmico - Visualização de animais cadastrados.</p>" +
            "<p>Projeto desenvolvido pelos alunos do segundo semestre de GTI na Fatec Campinas.</p>" +
            "<b>Alunos integrantes do desenvolvimento do projeto:</b>" +
            "<ul>" +
            "<li>Amanda Moura</li>" +
            "<li>Gabriella Ribeiro</li>" +
            "<li>Gabrielle Marcelino</li>" +
            "<li>Giovanna Marcondes</li>" +
            "<li>Pedro Augusto</li>" +
            "</ul>" +
            "<p><b>Aviso:</b> Este projeto foi desenvolvido com as limitações de conhecimento dos alunos no momento da sua realização.<br>" +
            "Algumas funcionalidades ainda estão em desenvolvimento ou não estão totalmente funcionais, mas temos o objetivo de aprimorar e evoluir o sistema para que ele funcione 100% futuramente.</p>" +
            "</html>"
        ));
        painelConteudo.add(painelSobre, "sobre");

        add(painelMenu, BorderLayout.WEST);
        add(painelConteudo, BorderLayout.CENTER);

        // Função para preencher tabela
        Runnable atualizarTabela = () -> {
            modeloTabela.setRowCount(0);
            String busca = txtBusca.getText().trim().toLowerCase();
            String classif = (String) comboClassificacao.getSelectedItem();
            List<SerVivo> lista = catalogo.getLista();
            if (!"Todas".equals(classif)) {
                lista = lista.stream().filter(s -> s.getClassificacao().equalsIgnoreCase(classif)).collect(Collectors.toList());
            }
            if (!busca.isEmpty()) {
                lista = lista.stream().filter(s -> s.getNomePopular().toLowerCase().contains(busca) ||
                                                   s.getNomeCientifico().toLowerCase().contains(busca)).collect(Collectors.toList());
            }
            for (SerVivo ser : lista) {
                modeloTabela.addRow(new Object[]{ser.getNomePopular(), ser.getClassificacao()});
            }
            lblDetalhes.setText("Selecione um animal para ver detalhes.");
            lblFoto.setIcon(null);
            lblFoto.setText("Sem foto");
        };

        // Preencher tabela ao abrir
        atualizarTabela.run();

        // Buscar ao clicar no botão
        btnFiltrar.addActionListener(ev -> atualizarTabela.run());

        // Buscar ao mudar classificação
        comboClassificacao.addActionListener(ev -> atualizarTabela.run());

        // Buscar ao digitar e apertar Enter
        txtBusca.addActionListener(ev -> atualizarTabela.run());

        // Mostrar detalhes ao selecionar animal
        tabela.getSelectionModel().addListSelectionListener(e2 -> {
            int linha = tabela.getSelectedRow();
            if (linha >= 0) {
                String nomePopular = (String) modeloTabela.getValueAt(linha, 0);
                SerVivo ser = catalogo.buscarPorNomePopular(nomePopular);
                if (ser != null) {
                    lblDetalhes.setText(
                        "<html><b>Nome Popular:</b> " + ser.getNomePopular() +
                        "<br><b>Nome Científico:</b> " + ser.getNomeCientifico() +
                        "<br><b>Classificação:</b> " + ser.getClassificacao() +
                        "<br><b>Descrição:</b> " + ser.getDescricao() + "</html>"
                    );
                    // Foto
                    java.io.File pastaFotos = new java.io.File("fotos");
                    java.io.File fotoJpg = new java.io.File(pastaFotos, nomePopular + ".jpg");
                    java.io.File fotoPng = new java.io.File(pastaFotos, nomePopular + ".png");
                    java.io.File foto = fotoJpg.exists() ? fotoJpg : (fotoPng.exists() ? fotoPng : null);
                    if (foto != null && foto.exists()) {
                        ImageIcon icon = new ImageIcon(foto.getAbsolutePath());
                        Image img = icon.getImage().getScaledInstance(220, 220, Image.SCALE_SMOOTH);
                        lblFoto.setIcon(new ImageIcon(img));
                        lblFoto.setText("");
                    } else {
                        lblFoto.setIcon(null);
                        lblFoto.setText("Sem foto");
                    }
                }
            }
        });

        // Troca o painel conforme o botão
        btnCatalogo.addActionListener(ev -> {
            CardLayout cl = (CardLayout) (painelConteudo.getLayout());
            cl.show(painelConteudo, "catalogo");
        });
        btnSobre.addActionListener(ev -> {
            CardLayout cl = (CardLayout) (painelConteudo.getLayout());
            cl.show(painelConteudo, "sobre");
        });
        btnVoltar.addActionListener(ev -> {
            dispose();
            new View.Mainswing();
        });

        setVisible(true);
        CardLayout cl = (CardLayout) (painelConteudo.getLayout());
        cl.show(painelConteudo, "catalogo");
    }
}

