package View;

import javax.swing.*;
import java.awt.*;
import Font.Catalogo;

public class Mainswing extends JFrame {
    private Catalogo catalogo;

    public Mainswing() {
        catalogo = new Catalogo();
        setTitle("Catálogo de Animais - Escolha o modo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel lblTitulo = new JLabel("Bem-vindo ao Catálogo de Animais");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);

        JButton btnAdmin = new JButton("Entrar como ADMIN");
        JButton btnUsuario = new JButton("Entrar como USUÁRIO");

        JPanel painelBotoes = new JPanel(new GridLayout(2, 1, 20, 20));
        painelBotoes.add(btnAdmin);
        painelBotoes.add(btnUsuario);

        add(lblTitulo, BorderLayout.NORTH);
        add(painelBotoes, BorderLayout.CENTER);

        // Ação dos botões
        btnAdmin.addActionListener(e -> {
            new View.admin.DashboardAdmin(catalogo);
            dispose();
        });

        btnUsuario.addActionListener(e -> {
            new View.usuario.TelaUsuario(catalogo);
            dispose();
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        new Mainswing();
    }
}

