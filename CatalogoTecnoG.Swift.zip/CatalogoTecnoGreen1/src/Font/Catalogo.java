package Font;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class Catalogo implements AnimalDataSource {

    private List<SerVivo> listaSeresVivos;

    public Catalogo() {
        File pastaDados = new File("dados");
        if (!pastaDados.exists()) {
            pastaDados.mkdirs();
        }
        this.listaSeresVivos = new ArrayList<>();
        carregarDoArquivo();
    }

    // --- Métodos da Interface AnimalDataSource ---

    @Override
    public List<SerVivo> getTodosSeresVivos() {
        return Collections.unmodifiableList(listaSeresVivos);
    }

    @Override
    public Set<String> getClassificacoesDisponiveis() {
        return listaSeresVivos.stream()
                .map(SerVivo::getClassificacao)
                .collect(Collectors.toCollection(TreeSet::new));
    }

    @Override
    public SerVivo buscarSerVivoPorNomePopular(String nomePopular) {
        for (SerVivo ser : listaSeresVivos) {
            if (ser.getNomePopular().equalsIgnoreCase(nomePopular.trim())) {
                return ser;
            }
        }
        return null;
    }

    @Override
    public SerVivo buscarSerVivoPorNomeCientifico(String nomeCientifico) {
        for (SerVivo ser : listaSeresVivos) {
            if (ser.getNomeCientifico().equalsIgnoreCase(nomeCientifico.trim())) {
                return ser;
            }
        }
        return null;
    }

    @Override
    public List<SerVivo> buscarSerVivoPorClassificacao(String classificacao) {
        return listaSeresVivos.stream()
                .filter(s -> s.getClassificacao().equalsIgnoreCase(classificacao.trim()))
                .collect(Collectors.toList());
    }

    @Override
    public void adicionarSerVivo(SerVivo serVivo) throws IllegalArgumentException, IOException {
        if (buscarSerVivoPorNomePopular(serVivo.getNomePopular()) != null) {
            throw new IllegalArgumentException("Erro: Já existe um animal com este nome popular.");
        }
        if (buscarSerVivoPorNomeCientifico(serVivo.getNomeCientifico()) != null) {
            throw new IllegalArgumentException("Erro: Já existe um animal com este nome científico.");
        }
        listaSeresVivos.add(serVivo);

        // Cria subpasta da classificação se não existir
        String pastaClassificacao = "dados/" + serVivo.getClassificacao();
        File pasta = new File(pastaClassificacao);
        if (!pasta.exists()) pasta.mkdirs();

        // Salva no arquivo catalogo.txt da classificação
        File arquivo = new File(pasta, "catalogo.txt");
        try (PrintWriter pw = new PrintWriter(new FileWriter(arquivo, true))) {
            pw.println("Animal;" + serVivo.getNomePopular() + ";" + serVivo.getNomeCientifico() + ";" +
                    serVivo.getClassificacao() + ";" + serVivo.getDescricao().replace("\n", "\\n"));
        }
    }

    @Override
    public void atualizarSerVivo(SerVivo serVivoAtualizado) throws IllegalArgumentException, IOException {
        SerVivo original = buscarSerVivoPorNomePopular(serVivoAtualizado.getNomePopular());
        if (original == null) {
            throw new IllegalArgumentException("Erro: Animal não encontrado para atualização.");
        }
        // Remove o animal antigo do arquivo da classificação antiga
        removerSerVivo(original.getNomePopular());

        // Adiciona o animal atualizado (pode ser em outra classificação)
        adicionarSerVivo(serVivoAtualizado);
        // Atualiza lista em memória
        carregarDoArquivo();
    }

    @Override
    public void removerSerVivo(String nomePopular) throws IllegalArgumentException, IOException {
        SerVivo serParaRemover = buscarSerVivoPorNomePopular(nomePopular);
        if (serParaRemover == null) {
            throw new IllegalArgumentException("Erro: Animal com nome popular '" + nomePopular + "' não encontrado para remoção.");
        }
        String pastaClassificacao = "dados/" + serParaRemover.getClassificacao();
        File arquivo = new File(pastaClassificacao, "catalogo.txt");
        List<String> linhas = new ArrayList<>();
        if (arquivo.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
                String linha;
                while ((linha = br.readLine()) != null) {
                    String[] partes = linha.split(";", 5);
                    if (partes.length >= 3 && !partes[1].equalsIgnoreCase(nomePopular.trim())) {
                        linhas.add(linha);
                    }
                }
            }
            try (PrintWriter pw = new PrintWriter(new FileWriter(arquivo))) {
                for (String l : linhas) {
                    pw.println(l);
                }
            }
        }
        listaSeresVivos.remove(serParaRemover);
    }

    // --- Métodos de Compatibilidade para telas antigas ---

    public List<SerVivo> getLista() {
        return listaSeresVivos;
    }

    public SerVivo buscarPorNomePopular(String nomePopular) {
        return buscarSerVivoPorNomePopular(nomePopular);
    }

    public SerVivo buscarPorNomeCientifico(String nomeCientifico) {
        return buscarSerVivoPorNomeCientifico(nomeCientifico);
    }

    public List<SerVivo> buscarPorClassificacao(String classificacao) {
        return buscarSerVivoPorClassificacao(classificacao);
    }

    // --- Métodos de Persistência por classificação ---

    private void carregarDoArquivo() {
        listaSeresVivos = new ArrayList<>();
        File pastaDados = new File("dados");
        if (!pastaDados.exists()) return;

        File[] subpastas = pastaDados.listFiles(File::isDirectory);
        if (subpastas != null) {
            for (File subpasta : subpastas) {
                File arquivo = new File(subpasta, "catalogo.txt");
                if (arquivo.exists()) {
                    try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
                        String linha;
                        while ((linha = br.readLine()) != null) {
                            String[] partes = linha.split(";", 5);
                            if (partes.length == 5) {
                                String nomePopular = partes[1];
                                String nomeCientifico = partes[2];
                                String classificacao = partes[3];
                                String descricao = partes[4].replace("\\n", "\n");
                                listaSeresVivos.add(new Animal(nomePopular, nomeCientifico, classificacao, descricao));
                            }
                        }
                    } catch (Exception ex) {
                        System.err.println("Erro ao ler " + arquivo.getAbsolutePath());
                    }
                }
            }
        }
    }
}