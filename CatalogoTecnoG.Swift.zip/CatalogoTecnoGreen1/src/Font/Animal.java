package Font;

import java.io.Serializable;

public class Animal extends SerVivo implements Serializable {
    private static final long serialVersionUID = 1L; // Adicionado para serialização

    // Atributo específico da classe Animal
    private String tipo; // Ex: "Doméstico", "Selvagem", "Exótico"

    // Construtor
    public Animal(String nomePopular, String nomeCientifico, String classificacao, String descricao, String tipo) {
        // Chama o construtor da superclasse SerVivo
        super(nomePopular, nomeCientifico, classificacao, descricao);
        // Define o atributo específico de Animal, com validação
        setTipo(tipo);
    }

    // Construtor adicional para compatibilidade, se a UI não for pedir o 'tipo' inicialmente
    // Mas a intenção é que os cadastros sempre definam o tipo.
    // Se você sempre for exigir o tipo no cadastro, pode remover este construtor.
    public Animal(String nomePopular, String nomeCientifico, String classificacao, String descricao) {
        // Chama o construtor da superclasse SerVivo
        super(nomePopular, nomeCientifico, classificacao, descricao);
        // Define um tipo padrão ou nulo se não for fornecido
        this.tipo = "Desconhecido"; // Ou null, dependendo da sua regra de negócio
    }


    // Getter para o atributo tipo
    public String getTipo() {
        return tipo;
    }

    // Setter para o atributo tipo com validação
    public void setTipo(String tipo) {
        if (tipo == null || tipo.trim().isEmpty()) {
            throw new IllegalArgumentException("Tipo do animal não pode ser nulo ou vazio.");
        }
        this.tipo = tipo.trim();
    }

    @Override
    public String toString() {
        // Chama o toString da superclasse e adiciona o atributo tipo
        return super.toString() + ", Tipo: " + tipo;
    }

    // Não há necessidade de sobrescrever equals/hashCode aqui
    // a menos que o "tipo" seja parte da identidade única do animal.
    // Geralmente, o nome popular (herdado de SerVivo) já é suficiente.
}