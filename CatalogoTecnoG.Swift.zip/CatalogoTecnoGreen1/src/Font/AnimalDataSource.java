package Font;

import java.io.IOException;
import java.util.List;
import java.util.Set;

public interface AnimalDataSource {
    List<SerVivo> getTodosSeresVivos();
    Set<String> getClassificacoesDisponiveis();
    SerVivo buscarSerVivoPorNomePopular(String nomePopular);
    SerVivo buscarSerVivoPorNomeCientifico(String nomeCientifico);
    List<SerVivo> buscarSerVivoPorClassificacao(String classificacao);
    void adicionarSerVivo(SerVivo serVivo) throws IllegalArgumentException, IOException;
    void atualizarSerVivo(SerVivo serVivo) throws IllegalArgumentException, IOException;
    void removerSerVivo(String nomePopular) throws IllegalArgumentException, IOException;
}