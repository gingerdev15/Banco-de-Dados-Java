package Font;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Catalogo catalogo = new Catalogo();
        boolean executando = true;

        while (executando) {
            System.out.println("\nEscolha o tipo de usuário:");
            System.out.println("1 - Administrador (Cadastrar animais)");
            System.out.println("2 - Usuário Final (Pesquisar animal)");
            System.out.println("3 - Sair");
            System.out.print("Opção: ");

            int tipoUsuario = lerOpcao(scanner);

            switch (tipoUsuario) {
                case 1:
                    menuAdministrador(scanner, catalogo);
                    break;
                case 2:
                    menuUsuarioFinal(scanner, catalogo);
                    break;
                case 3:
                    System.out.println("Encerrando o programa.");
                    executando = false;
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }

        scanner.close();
    }

    private static void menuAdministrador(Scanner scanner, Catalogo catalogo) {
        boolean voltar = false;
        while (!voltar) {
            System.out.println("\n-- Menu Administrador --");
            System.out.println("1 - Adicionar Animal");
            System.out.println("2 - Listar Catálogo");
            System.out.println("3 - Voltar");
            System.out.print("Opção: ");

            int opcao = lerOpcao(scanner);

            switch (opcao) {
                case 1:
                    System.out.print("Nome Popular: ");
                    String nomePopular = scanner.nextLine();
                    System.out.print("Nome Científico: ");
                    String nomeCientifico = scanner.nextLine();
                    System.out.print("Classificação: ");
                    String classificacao = scanner.nextLine();
                    System.out.print("Descrição: ");
                    String descricao = scanner.nextLine();

                    Animal animal = new Animal(nomePopular, nomeCientifico, classificacao, descricao);
                    try {
                        catalogo.adicionarSerVivo(animal);
                        System.out.println("Animal cadastrado com sucesso!");
                    } catch (Exception ex) {
                        System.out.println("Erro ao cadastrar: " + ex.getMessage());
                    }
                    break;
                case 2:
                    listarClassificacoes(scanner, catalogo);
                    break;
                case 3:
                    voltar = true;
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }

    private static void menuUsuarioFinal(Scanner scanner, Catalogo catalogo) {
        boolean voltar = false;
        while (!voltar) {
            System.out.println("\n-- Menu Usuário Final --");
            System.out.println("1 - Buscar por nome");
            System.out.println("2 - Buscar por classificação");
            System.out.println("3 - Voltar");
            System.out.print("Opção: ");

            int opcaoUsuario = lerOpcao(scanner);

            switch (opcaoUsuario) {
                case 1:
                    System.out.print("Digite o nome popular ou científico do animal: ");
                    String nomeBusca = scanner.nextLine();
                    SerVivo resultado = catalogo.buscarPorNomePopular(nomeBusca);
                    if (resultado == null) {
                        resultado = catalogo.buscarPorNomeCientifico(nomeBusca);
                    }
                    if (resultado != null) {
                        System.out.println("Animal encontrado:");
                        System.out.println("Nome Popular: " + resultado.getNomePopular());
                        System.out.println("Nome Científico: " + resultado.getNomeCientifico());
                        System.out.println("Classificação: " + resultado.getClassificacao());
                        System.out.println("Descrição: " + resultado.getDescricao());
                    } else {
                        System.out.println("Animal não encontrado.");
                    }
                    break;
                case 2:
                    List<String> classificacoes = new ArrayList<>(catalogo.getClassificacoesDisponiveis());
                    if (classificacoes.isEmpty()) {
                        System.out.println("Nenhuma classificação encontrada.");
                    } else {
                        System.out.println("Classificações disponíveis:");
                        for (int i = 0; i < classificacoes.size(); i++) {
                            System.out.println((i + 1) + " - " + classificacoes.get(i));
                        }
                        System.out.print("Escolha uma classificação: ");
                        int escolha = lerOpcao(scanner);
                        if (escolha >= 1 && escolha <= classificacoes.size()) {
                            String classif = classificacoes.get(escolha - 1);
                            List<SerVivo> animais = catalogo.buscarPorClassificacao(classif);
                            if (animais.isEmpty()) {
                                System.out.println("Nenhum animal encontrado para essa classificação.");
                            } else {
                                for (SerVivo ser : animais) {
                                    System.out.println("Nome Popular: " + ser.getNomePopular());
                                    System.out.println("Nome Científico: " + ser.getNomeCientifico());
                                    System.out.println("Descrição: " + ser.getDescricao());
                                    System.out.println("----------------------");
                                }
                            }
                        } else {
                            System.out.println("Opção inválida.");
                        }
                    }
                    break;
                case 3:
                    voltar = true;
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }

    private static void listarClassificacoes(Scanner scanner, Catalogo catalogo) {
        List<String> opcoes = new ArrayList<>(catalogo.getClassificacoesDisponiveis());

        if (opcoes.isEmpty()) {
            System.out.println("Nenhuma classificação encontrada.");
        } else {
            System.out.println("Classificações disponíveis:");
            for (int i = 0; i < opcoes.size(); i++) {
                System.out.println((i + 1) + " - " + opcoes.get(i));
            }

            System.out.print("Escolha uma classificação para listar: ");
            int escolhaClasse = lerOpcao(scanner);

            if (escolhaClasse >= 1 && escolhaClasse <= opcoes.size()) {
                String classificacaoEscolhida = opcoes.get(escolhaClasse - 1);
                List<SerVivo> animais = catalogo.buscarPorClassificacao(classificacaoEscolhida);
                if (animais.isEmpty()) {
                    System.out.println("Nenhum animal encontrado para essa classificação.");
                } else {
                    for (SerVivo ser : animais) {
                        System.out.println("Nome Popular: " + ser.getNomePopular());
                        System.out.println("Nome Científico: " + ser.getNomeCientifico());
                        System.out.println("Descrição: " + ser.getDescricao());
                        System.out.println("----------------------");
                    }
                }

                System.out.print("Deseja editar algum animal desta lista? (s/n): ");
                String editar = scanner.nextLine();

                if (editar.equalsIgnoreCase("s")) {
                    System.out.print("Digite o nome popular do animal a ser editado: ");
                    String nomeEdicao = scanner.nextLine();
                    SerVivo ser = catalogo.buscarPorNomePopular(nomeEdicao);
                    if (ser != null) {
                        System.out.print("Novo nome popular: ");
                        ser.setNomePopular(scanner.nextLine());
                        System.out.print("Novo nome científico: ");
                        ser.setNomeCientifico(scanner.nextLine());
                        System.out.print("Nova classificação: ");
                        ser.setClassificacao(scanner.nextLine());
                        System.out.print("Nova descrição: ");
                        ser.setDescricao(scanner.nextLine());
                        try {
                            catalogo.atualizarSerVivo(ser);
                            System.out.println("Animal editado com sucesso!");
                        } catch (Exception ex) {
                            System.out.println("Erro ao salvar: " + ex.getMessage());
                        }
                    } else {
                        System.out.println("Animal não encontrado.");
                    }
                }

            } else {
                System.out.println("Opção inválida.");
            }
        }
    }

    private static int lerOpcao(Scanner scanner) {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
