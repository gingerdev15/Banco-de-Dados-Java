package Font;

import java.io.Serializable;
import java.util.Objects; // Importe para usar Objects.hash e Objects.equals

// SerVivo agora é uma classe abstrata, pois Animal a estende e ela tem atributos comuns.
public abstract class SerVivo implements Serializable {
    private static final long serialVersionUID = 1L; // Adicionado para serialização

    // Atributos agora são privados
    private String nomePopular;
    private String nomeCientifico;
    private String classificacao; // Ex: Mamífero, Ave, Réptil
    private String descricao;

    // Construtor
    public SerVivo(String nomePopular, String nomeCientifico, String classificacao, String descricao) {
        // Chamando os setters para aplicar validação inicial
        setNomePopular(nomePopular);
        setNomeCientifico(nomeCientifico);
        setClassificacao(classificacao);
        setDescricao(descricao);
    }

    // Getters públicos (para acessar os valores)
    public String getNomePopular() {
        return nomePopular;
    }

    public String getNomeCientifico() {
        return nomeCientifico;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public String getDescricao() {
        return descricao;
    }

    // Setters públicos com validação
    public void setNomePopular(String nomePopular) {
        if (nomePopular == null || nomePopular.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome popular não pode ser nulo ou vazio.");
        }
        this.nomePopular = nomePopular.trim();
    }

    public void setNomeCientifico(String nomeCientifico) {
        if (nomeCientifico == null || nomeCientifico.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome científico não pode ser nulo ou vazio.");
        }
        this.nomeCientifico = nomeCientifico.trim();
    }

    public void setClassificacao(String classificacao) {
        if (classificacao == null || classificacao.trim().isEmpty()) {
            throw new IllegalArgumentException("Classificação não pode ser nula ou vazia.");
        }
        this.classificacao = classificacao.trim();
    }

    public void setDescricao(String descricao) {
        if (descricao == null || descricao.trim().isEmpty()) {
            throw new IllegalArgumentException("Descrição não pode ser nula ou vazia.");
        }
        this.descricao = descricao.trim();
    }

    // Método toString para fácil visualização
    @Override
    public String toString() {
        return "Nome Popular: " + nomePopular +
               ", Nome Científico: " + nomeCientifico +
               ", Classificação: " + classificacao +
               ", Descrição: " + descricao;
    }

    // Sobrescrita de equals e hashCode para permitir comparação por valor
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SerVivo serVivo = (SerVivo) o;
        // Considerando que o nome popular é o identificador único para SerVivo
        return Objects.equals(nomePopular, serVivo.nomePopular);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nomePopular);
    }
}